# IMAGE-PROCESSSING-DIGITAL-ASSIGNMENT-2
Implement frequency domain filtering apart from Fourier transform, apply any two filtering for any image processing application and Homomorphic Filtering of an Image using MATLAB…..


1.Image smoothing and sharpening using frequency domain filters in image processing(smoothing.m,sharpening.m)


2.Filtering of an image in frequency domain(low pass filter)(image_frequency_filter.m)


3.Homomorphic Filtering of an Image(homo.m)
